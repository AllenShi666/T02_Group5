import java.util.ArrayList;

public interface EventArrayListClass {

	public ArrayList<Event>globalEventList = new ArrayList<Event>();
	
}
